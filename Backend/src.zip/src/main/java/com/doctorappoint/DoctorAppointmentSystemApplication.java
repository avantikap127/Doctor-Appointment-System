package com.doctorappoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorAppointmentSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(DoctorAppointmentSystemApplication.class, args);
    }
}
/*mvn spring-boot:run */