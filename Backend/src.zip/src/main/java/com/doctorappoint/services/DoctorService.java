package com.doctorappoint.services;

import com.doctorappoint.model.Doctor;
import com.doctorappoint.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository repo;

    // ✅ Get doctors by hospital
    public List<Doctor> getDoctorsByHospital(Long hospitalId) {

        if (hospitalId == null) {
            throw new RuntimeException("Hospital ID cannot be null");
        }

        return repo.findByHospital_HospitalId(hospitalId);
    }
}