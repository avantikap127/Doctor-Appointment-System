package com.doctorappoint.services;

import com.doctorappoint.model.User;
import com.doctorappoint.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepo;

    // ✅ Register user
    public User register(User user) {

        if (user.getEmail() == null || user.getPassword() == null) {
            throw new RuntimeException("Email or Password cannot be null");
        }

        // Optional: check if user already exists
        User existingUser = userRepo.findByEmail(user.getEmail());
        if (existingUser != null) {
            throw new RuntimeException("User already exists with this email");
        }

        return userRepo.save(user);
    }

    // ✅ Login user
    public User login(String email, String password) {

    User user = userRepo.findByEmail(email);

    if (user == null) {
        throw new RuntimeException("User not found with email: " + email);
    }

    if (!user.getPassword().equals(password)) {
        throw new RuntimeException("Wrong password");
    }

    return user;
}
}