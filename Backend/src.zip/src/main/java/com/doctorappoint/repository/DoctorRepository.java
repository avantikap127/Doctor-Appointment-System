package com.doctorappoint.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.doctorappoint.model.Doctor;
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    List<Doctor> findByHospital_HospitalId(Long hospitalId);
}
